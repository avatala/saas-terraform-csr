curl -X POST https://us-east4-saas9008-admin-host.cloudfunctions.net/master-cf-test-cf \
-H "Authorization: bearer $(gcloud auth print-identity-token)" \
-H "Content-Type: application/json" \
-d '{
    "operation": "deleteTenant",
    "tenantId": "test"
    }'
