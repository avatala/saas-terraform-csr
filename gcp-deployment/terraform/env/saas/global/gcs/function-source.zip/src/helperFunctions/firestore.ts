import { getFirestore, Timestamp } from "firebase-admin/firestore";
import { WhereOperations } from "../types";
import { FirebaseService } from "./firebase";

export class FirestoreDB extends FirebaseService {
	db: FirebaseFirestore.Firestore;

	constructor() {
		super();
		this.db = getFirestore();
	}

	async getDocuments(collectionName: string) {
		const result = await this.db.collection(collectionName).get();

		return result;
	}

	getArrayOfDocs(
		docsObject: FirebaseFirestore.QuerySnapshot<FirebaseFirestore.DocumentData>
	) {
		const data: Array<FirebaseFirestore.DocumentData> = [];
		docsObject.forEach((doc) => data.push(doc.data()));
		return data;
	}

	toFirestoreTimestamp(seconds: number, nanos: number) {
		return new Timestamp(seconds, nanos);
	}

	async conditionalGetDocuments(
		collectionName: string,
		key: string,
		condition: string,
		searchValue: string
	) {
		const result = await this.db
			.collection(collectionName)
			.where(key, WhereOperations[condition], searchValue)
			.get();

		return result;
	}

	async addDocument(collectionName: string, document: { [k: string]: any }) {
		const result = await this.db.collection(collectionName).add(document);

		return result;
	}

	async conditionalDeleteDocument(
		collectionName: string,
		key: string,
		condition: string,
		searchValue: string
	) {
		const documents = this.db
			.collection(collectionName)
			.where(key, WhereOperations[condition], searchValue);

		await documents.get().then(function (querySnapshot) {
			querySnapshot.forEach(function (doc) {
				doc.ref.delete();
			});
		});
	}

	async conditionalUpdateDocument(
		collectionName: string,
		key: string,
		condition: string,
		searchValue: string,
		updateBody: { [k: string]: any }
	) {
		const documents = this.db
			.collection(collectionName)
			.where(key, WhereOperations[condition], searchValue);

		await documents.get().then(function (querySnapshot) {
			querySnapshot.forEach(function (doc) {
				doc.ref.update(updateBody);
			});
		});
	}

	async batchWriteArrayOfObjectsInSubcollection(
		collectionName: string,
		documentId: string,
		subcollectionName: string,
		arrayOfObjects: Array<Object>
	) {
		const batch = this.db.batch();
		const collectionRef = this.db.collection(collectionName);
		const subcollectionDocRef = collectionRef
			.doc(documentId)
			.collection(subcollectionName);

		arrayOfObjects.forEach((element) => {
			batch.set(subcollectionDocRef.doc(), element);
		});

		await batch.commit();
	}

	async addDocumentWithDocId(
    	collectionName: string,
    	documentId: string,
    	documentContent: any
  	) {
    	const result = await this.db.collection(collectionName).doc(documentId).set(documentContent);
		return result; 
  	}
}
