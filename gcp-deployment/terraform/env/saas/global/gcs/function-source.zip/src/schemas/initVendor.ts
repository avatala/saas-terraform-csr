import * as yup from "yup";
import { requestPayload } from "./base";

export const initVendorRequest = yup
	.object({
		defaultVendorEmail: yup.string().required(),
		defaultVendorName: yup.string().required(),
		defaultVendorOrgName: yup.string().required(),
		landingPageDataStudioUrl: yup.string().required(),
		costDataStudioUrl: yup.string().required(),
		usageDataStudioUrl: yup.string().required(),
		cloudBuildProjectId: yup.string().required(),
		freemiumCloudBuildTrigger: yup.string().required(),
		freemiumCloudBuildRepoName: yup.string().required(),
		freemiumCloudBuildBranchName: yup.string().required(),
		freemiumCloudBuildProjectLocation: yup.string().required(),
		enterpriseCloudBuildTrigger: yup.string().required(),
		enterpriseCloudBuildRepoName: yup.string().required(),
		enterpriseCloudBuildBranchName: yup.string().required(),
		enterpriseCloudBuildProjectLocation: yup.string().required(),
		deleteFreemiumCloudBuildTrigger: yup.string().required(),
		deleteFreemiumCloudBuildProjectLocation: yup.string().required(),
		deleteFreemiumCloudBuildRepoName: yup.string().required(),
		deleteFreemiumCloudBuildBranchName: yup.string().required(),
		deleteEnterpriseCloudBuildTrigger: yup.string().required(),
		deleteEnterpriseCloudBuildProjectLocation: yup.string().required(),
		deleteEnterpriseCloudBuildRepoName: yup.string().required(),
		deleteEnterpriseCloudBuildBranchName: yup.string().required(),
		freemiumSubdomain: yup.string().required(),
		enterpriseSubdomain: yup.string().required(),
		asmDashboardUrl: yup.string().required(),
		logMonDashboardUrl: yup.string().required(),
		updateFreemiumCloudBuildProjectLocation: yup.string().required(),
		updateFreemiumCloudBuildTrigger: yup.string().required(),
		idpEnterpriseCloudBuildTriggerlocation: yup.string().required(),
		idpEnterpriseCloudBuildTrigger: yup.string().required(),
		freemiumProjectId: yup.string().required(),
	})
	.concat(requestPayload);
