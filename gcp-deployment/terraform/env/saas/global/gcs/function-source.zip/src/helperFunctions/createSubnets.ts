import { SubnetData } from "../types";
import ip from "ip";

export class createSubnets {
	// Create subnets for small tenants
	smallTenant = (): Array<SubnetData> => {
		let result: Array<SubnetData> = [];

		let resultStart: SubnetData = {
			subnetIp: ip.toLong("10.160.0.0"),
			masterIp: ip.toLong("10.190.0.0"),
			podIp: ip.toLong("10.161.0.0"),
			svcIp: ip.toLong("10.162.0.0"),
			maxCount: 10,
			minCount: 5,
			nodeCount: 5,
			machineType: "e2-standard-4",
			tenantId: null,
			subnetId: "sm_subnet_1",
		};

		const smallIter = {
			subnetIter: ip.toLong("0.0.0.128"),
			masterIter: ip.toLong("0.0.0.16"),
			podIter: ip.toLong("0.0.2.0"),
			svcIter: ip.toLong("0.0.0.128"),
		};

		result.push(resultStart);

		for (let index = 0; index < 100; index++) {
			//Custom Iteration logic for subnetRange
			let subnetIp = ip.fromLong(result[index].subnetIp);
			let subnetIpIter = smallIter.subnetIter;
			if (subnetIp === "10.160.0.128") {
				subnetIpIter = ip.toLong("0.0.1.0");
			}
			//Custom Iteration logic for masterIp
			let masterIp = ip.fromLong(result[index].masterIp);
			let lastOctet = masterIp.slice(masterIp.lastIndexOf("."));
			let masterIpIter = smallIter.masterIter;
			if (lastOctet == ".32") {
				masterIpIter = ip.toLong("0.0.0.224");
			}
			if (masterIp === "10.190.0.0") {
				masterIpIter = ip.toLong("0.0.1.0");
			}
			//Custom Iteration logic for subnetRange
			let svcIp = ip.fromLong(result[index].svcIp);
			let svcIpIter = smallIter.subnetIter;
			if (svcIp === "10.162.0.0") {
				svcIpIter = ip.toLong("0.0.1.0");
			}

			let resultIter: SubnetData = {
				subnetIp: result[index].subnetIp + subnetIpIter,
				masterIp: result[index].masterIp + masterIpIter,
				podIp: result[index].podIp + smallIter.podIter,
				svcIp: result[index].svcIp + svcIpIter,
				maxCount: result[index].maxCount,
				minCount: result[index].minCount,
				nodeCount: result[index].nodeCount,
				machineType: result[index].machineType,
				tenantId: result[index].tenantId,
				subnetId: "sm_subnet_" + (index + 2),
			};

			result.push(resultIter);
		}

		result.map((e) => {
			e.subnetIp = ip.fromLong(e.subnetIp) + "/25";
			e.masterIp = ip.fromLong(e.masterIp) + "/28";
			e.podIp = ip.fromLong(e.podIp) + "/23";
			e.svcIp = ip.fromLong(e.svcIp) + "/25";
		});

		return result;
	};

	// Medium Tenant Subnet Initialise
	mediumTenant = (): Array<SubnetData> => {
		let result: Array<SubnetData> = [];

		let resultStart: SubnetData = {
			subnetIp: ip.toLong("10.163.1.0"),
			masterIp: ip.toLong("10.191.1.0"),
			podIp: ip.toLong("10.165.0.0"),
			svcIp: ip.toLong("10.167.1.0"),
			maxCount: 15,
			minCount: 10,
			nodeCount: 10,
			machineType: "e2-standard-4",
			tenantId: null,
			subnetId: "md_subnet_1",
		};

		const mediumIter = {
			subnetIter: ip.toLong("0.0.0.128"),
			masterIter: ip.toLong("0.0.0.16"),
			podIter: ip.toLong("0.0.2.0"),
			svcIter: ip.toLong("0.0.1.0"),
		};

		result.push(resultStart);

		for (let index = 0; index < 99; index++) {
			//Custom Iteration logic for masterIp
			let masterIp = ip.fromLong(result[index].masterIp);
			let lastOctet = masterIp.slice(masterIp.lastIndexOf("."));
			let masterIpIter = mediumIter.masterIter;
			if (lastOctet == ".32") {
				masterIpIter = ip.toLong("0.0.0.224");
			}
			let resultIter: SubnetData = {
				subnetIp: result[index].subnetIp + mediumIter.subnetIter,
				masterIp: result[index].masterIp + masterIpIter,
				podIp: result[index].podIp + mediumIter.podIter,
				svcIp: result[index].svcIp + mediumIter.svcIter,
				maxCount: result[index].maxCount,
				minCount: result[index].minCount,
				nodeCount: result[index].nodeCount,
				machineType: result[index].machineType,
				tenantId: result[index].tenantId,
				subnetId: "md_subnet_" + (index + 2),
			};

			result.push(resultIter);
		}

		result.map((e) => {
			e.subnetIp = ip.fromLong(e.subnetIp) + "/25";
			e.masterIp = ip.fromLong(e.masterIp) + "/28";
			e.podIp = ip.fromLong(e.podIp) + "/23";
			e.svcIp = ip.fromLong(e.svcIp) + "/24";
		});

		return result;
	};

	// Create Large Tenant Subnets
	largeTenant = (): Array<SubnetData> => {
		let result: Array<SubnetData> = [];

		let resultStart: SubnetData = {
			subnetIp: ip.toLong("10.169.0.0"),
			masterIp: ip.toLong("10.192.1.0"),
			podIp: ip.toLong("10.171.0.0"),
			svcIp: ip.toLong("10.173.1.0"),
			maxCount: 25,
			minCount: 20,
			nodeCount: 20,
			machineType: "e2-standard-8",
			tenantId: null,
			subnetId: "lg_subnet_1",
		};

		const largeIter = {
			subnetIter: ip.toLong("0.0.2.0"),
			masterIter: ip.toLong("0.0.0.16"),
			podIter: ip.toLong("0.0.4.0"),
			svcIter: ip.toLong("0.0.1.0"),
		};

		result.push(resultStart);

		for (let index = 0; index < 99; index++) {
			//Custom Iteration logic for masterIp
			let masterIp = ip.fromLong(result[index].masterIp);
			let lastOctet = masterIp.slice(masterIp.lastIndexOf("."));
			let masterIpIter = largeIter.masterIter;
			if (lastOctet == ".32") {
				masterIpIter = ip.toLong("0.0.0.224");
			}

			//Custom Iteration Logic for podIp in Large Tenant
			let podIp = ip.fromLong(result[index].podIp);
			let thirdOctet = podIp.split(".")[2];
			let podIter = ip.toLong("0.0.4.0");

			let resultIter: SubnetData = {
				subnetIp: result[index].subnetIp + largeIter.subnetIter,
				masterIp: result[index].masterIp + masterIpIter,
				podIp: result[index].podIp + podIter,
				svcIp: result[index].svcIp + largeIter.svcIter,
				maxCount: result[index].maxCount,
				minCount: result[index].minCount,
				nodeCount: result[index].nodeCount,
				machineType: result[index].machineType,
				tenantId: result[index].tenantId,
				subnetId: "lg_subnet_" + (index + 2),
			};

			result.push(resultIter);
		}

		result.map((e) => {
			e.subnetIp = ip.fromLong(e.subnetIp) + "/23";
			e.masterIp = ip.fromLong(e.masterIp) + "/28";
			e.podIp = ip.fromLong(e.podIp) + "/22";
			e.svcIp = ip.fromLong(e.svcIp) + "/24";
		});

		return result;
	};
}
