// module imports
import { CloudBuildClient } from "@google-cloud/cloudbuild";
import { google } from "@google-cloud/cloudbuild/build/protos/protos";

// internal imports
import { StatusCodes } from "../config";
import { newErrorMessage } from "./newErrorMessage";
import { Operations, Tiers } from "../types";

export class CBClient {
	cb: CloudBuildClient;
	STATUS_LOOKUP: Array<string>;

	constructor() {
		this.cb = new CloudBuildClient();
		this.STATUS_LOOKUP = [
			"UNKNOWN",
			"Queued",
			"Working",
			"Success",
			"Failure",
			"Error",
			"Timeout",
			"Cancelled",
		];
	}

	async getBuildStatus(
		projectId: string,
		location: string,
		id: string
	): Promise<CBClient.GetBuildStatusResult> {
		return new Promise(async (resolve, reject) => {
			try {
				// Construct request
				const request = {
					name: `projects/${projectId}/locations/${location}/builds/${id}`
				};

				// Run request
				const [resp] = await this.cb.getBuild(request);

				const result: CBClient.GetBuildStatusResult = {
					id: resp.id,
					status: resp.status,
					startTime: resp.startTime,
					finishTime: resp.finishTime,
					logUrl: resp.logUrl,
					source: {
						repoSource: {
							repoName: resp.source?.repoSource?.repoName,
						},
					},
					failureInfo: {
						type: resp.failureInfo?.type,
						detail: resp.failureInfo?.detail,
					},
				};

				resolve(result);
			} catch (error) {
				reject(
					newErrorMessage(
						500,
						"getBuildStatus",
						StatusCodes.internalServerError,
						error.message
					)
				);
			}
		});
	}

	private getCloudBuildConfigVars(operation: string, tier: string) {
		let projectId: string = process.env.CLOUD_BUILD_PROJECT_ID;
		let triggerId: string;
		let projectLocation: string;
		let repoName: string;
		let branchName: string;

		switch (operation) {
			case Operations.create:
				switch (tier) {
					case Tiers.freemium:
						triggerId = process.env.FREEMIUM_CLOUD_BUILD_TRIGGER_ID;
						projectLocation =
							process.env.FREEMIUM_CLOUD_BUILD_PROJECT_LOCATION;
						repoName = process.env.FREEMIUM_CLOUD_BUILD_REPO_NAME;
						branchName =
							process.env.FREEMIUM_CLOUD_BUILD_BRANCH_NAME;
						break;
					case Tiers.enterprise:
						triggerId =
							process.env.ENTERPRISE_CLOUD_BUILD_TRIGGER_ID;
						projectLocation =
							process.env.ENTERPRISE_CLOUD_BUILD_PROJECT_LOCATION;
						repoName = process.env.ENTERPRISE_CLOUD_BUILD_REPO_NAME;
						branchName =
							process.env.ENTERPRISE_CLOUD_BUILD_BRANCH_NAME;
						break;
					default:
						throw "Invalid tier.";
						break;
				}
				break;
			default:
				throw "Invalid operation.";
				break;
		}

		return {
			projectId,
			triggerId,
			projectLocation,
			repoName,
			branchName,
		};
	}

	async runBuildTrigger(
		operation: string,
		tier: string,
		substitutions: { [k: string]: any }
	): Promise<void> {
		return new Promise(async (resolve, reject) => {
			try {

        console.log(operation, " operation <--> tier ",tier)

				let cloudBuildConfigVars = this.getCloudBuildConfigVars(
					operation,
					tier
				);

        // console.log(JSON.stringify(cloudBuildConfigVars))

				const [resp] = await this.cb.runBuildTrigger({
					projectId: cloudBuildConfigVars.projectId,
					triggerId: cloudBuildConfigVars.triggerId,
					name: `projects/${cloudBuildConfigVars.projectId}/locations/${cloudBuildConfigVars.projectLocation}/triggers/${cloudBuildConfigVars.triggerId}`,
					source: {
						repoName: cloudBuildConfigVars.repoName,
						dir: "/",
						substitutions: substitutions,
						branchName: cloudBuildConfigVars.branchName,
					},
				});

				const [build] = await resp.promise();
				if (build.status === "STATUS_UNKNOWN") {
					throw `${build.status} : Can't determine status of the build.`;
				} else if (
					build.status === "QUEUED" ||
					build.status === "WORKING" ||
					build.status === "SUCCESS"
				) {
					resolve();
				} else if (build.status === "CANCELLED") {
					throw `${build.status} : Execution of Build Trigger cancelled.`;
				} else if (
					build.status === "FAILURE" ||
					build.status === "INTERNAL_ERROR"
				) {
					throw `${build.status} : Execution of Build Trigger failed due to an error. Check logs for more details.`;
				} else if (
					build.status === "EXPIRED" ||
					build.status === "TIMEOUT"
				) {
					throw `${build.status} : Unknown error. Check logs for more details.`;
				}
			} catch (error) {
				reject(
					newErrorMessage(
						500,
						"runBuildTrigger",
						StatusCodes.internalServerError,
						error.message
					)
				);
			}
		});
	}
}

export namespace CBClient {
	export type GetBuildStatusResult = {
		id?: string | null;
		status?:
		| google.devtools.cloudbuild.v1.Build.Status
		| keyof typeof google.devtools.cloudbuild.v1.Build.Status
		| null;
		startTime: google.protobuf.ITimestamp | null | undefined;
		finishTime: google.protobuf.ITimestamp | null | undefined;
		logUrl?: string | null;
		source: {
			repoSource: {
				repoName?: string | null;
			};
		};
		failureInfo: {
			type?:
			| google.devtools.cloudbuild.v1.Build.FailureInfo.FailureType
			| keyof typeof google.devtools.cloudbuild.v1.Build.FailureInfo.FailureType
			| null;
			detail?: string | null;
		};
	};
}
