// module imports
import * as ff from "@google-cloud/functions-framework";

// internal imports
import { RequestOperation, StatusCodes } from "./config";
import { newErrorMessage, verifyPayload } from "./helperFunctions";

import {
	createTenantAdmin,
	updateTenancy,
	updateTenantInfo,
	initVendor,
	updateVendor,
	tenantOnboardingStatus,
	runTrigger,
	initTenantStatus,
	sendApigeeCreds,
	deleteTenant,
} from "./requestHandlers";

import {
	CreateTenantAdminRequest,
	InitVendorRequest,
	UpdateVendorRequest,
	TenantOnboardingStatusRequest,
	UpdateTenancyRequest,
	UpdateTenantInfoRequest,
	InitTenantStatusRequest,
	SendApigeeCredsRequest,
	DeleteTenantRequest,
} from "./types";
import { checkEmailVerified } from "./requestHandlers/checkEmailVerified";

// Environment variables declaration
declare global {
	namespace NodeJS {
		interface ProcessEnv {
			CLOUD_BUILD_PROJECT_ID: string;
			FREEMIUM_CLOUD_BUILD_TRIGGER_ID: string;
			FREEMIUM_CLOUD_BUILD_PROJECT_LOCATION: string;
			FREEMIUM_CLOUD_BUILD_REPO_NAME: string;
			FREEMIUM_CLOUD_BUILD_BRANCH_NAME: string;
			ENTERPRISE_CLOUD_BUILD_TRIGGER_ID: string;
			ENTERPRISE_CLOUD_BUILD_PROJECT_LOCATION: string;
			ENTERPRISE_CLOUD_BUILD_REPO_NAME: string;
			ENTERPRISE_CLOUD_BUILD_BRANCH_NAME: string;
		}
	}
}

// performAction - Entry point of the cloud function
export const performAction = async (req: ff.Request, res: ff.Response) => {
	try {
		// payload = The request body sent along with the request.
		const payload:
			| CreateTenantAdminRequest
			| InitVendorRequest
			| UpdateVendorRequest
			| TenantOnboardingStatusRequest
			| UpdateTenancyRequest
			| UpdateTenantInfoRequest
			| InitTenantStatusRequest
			| DeleteTenantRequest
			| SendApigeeCredsRequest = req.body;

		// verifying payload received
		await verifyPayload(payload);

		// deciding the action to be performed based on payload.operation
		switch (payload.operation) {
			case RequestOperation.createTenantAdmin:
				await createTenantAdmin(payload);
				break;
			case RequestOperation.initVendor:
				await initVendor(payload);
				break;
			case RequestOperation.updateVendor:
				await updateVendor(payload);
				break;
			case RequestOperation.updateTenancy:
				await updateTenancy(payload);
				break;
			case RequestOperation.updateTenantInfo:
				await updateTenantInfo(payload);
				break;
			case RequestOperation.tenantOnboardingStatus:
				await tenantOnboardingStatus(payload);
				break;
			case RequestOperation.initTenantStatus:
				await initTenantStatus(payload);
				break;
			case RequestOperation.apigeeCreds:
				await sendApigeeCreds(payload);
				break;
			case RequestOperation.deleteTenant:
				await deleteTenant(payload);
				break;
			default:
				return res
					.status(500)
					.send(
						`\n....\nError Code: ${StatusCodes.invalidOperation}\n....\n\n`
					);
		}

		return res.status(200).end();
	} catch (error: any) {
		console.log(error);
		return res.status(error.status).send(error.message);
	}
};

export const performTrigger = async (req: ff.Request, res: ff.Response) => {
	try {
		const { subdomain } = req.query;
    console.log(subdomain,",subdomain")

		if (typeof subdomain !== "string") {
			throw newErrorMessage(
				500,
				"performTrigger",
				StatusCodes.invalidTenantOnboardingRequest,
				"The query parameter is invalid. It must only be a string."
			);
		}

		const isEmailVerified: boolean = await checkEmailVerified(subdomain);
		if (isEmailVerified) {
			runTrigger(subdomain);
			res.status(200).sendFile(process.cwd() + "/src/views/success.html");
		} else {
			res.status(200).sendFile(
				process.cwd() + "/src/views/emailVerified.html"
			);
		}
		return;
	} catch (error: any) {
		console.log(error);
		return res.status(error.status).send(error.message);
	}
};

ff.http("performAction", performAction);

ff.http("performTrigger", performTrigger);
