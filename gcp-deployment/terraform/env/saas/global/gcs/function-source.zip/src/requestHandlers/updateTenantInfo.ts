// internal imports
import { StatusCodes } from "../config";
import { FirestoreDB, newErrorMessage } from "../helperFunctions";

export const updateTenantInfo = async (payload: any): Promise<void> => {
	return new Promise(async (resolve, reject) => {
		try {
			const db = new FirestoreDB();

			await db.conditionalUpdateDocument(
				"tenant",
				"subdomain",
				"equal",
				payload.tenantId,
				{ info: payload.info }
			);

			resolve();
		} catch (error) {
			reject(
				newErrorMessage(
					500,
					"updateTenantInfo",
					StatusCodes.internalServerError,
					error.message
				)
			);
		}
	});
};
