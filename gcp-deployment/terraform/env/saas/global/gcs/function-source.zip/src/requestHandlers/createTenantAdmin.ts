// module imports
import * as crypto from "node:crypto";
import { auth } from 'firebase-admin';
import { FirebaseService, newErrorMessage } from "../helperFunctions";
import { StatusCodes } from "../config";
import { EmailService } from "../helperFunctions";
import { Auth } from "firebase-admin/lib/auth/auth";

const actionCodeSettings = {
  url: `https://${process.env.ADMIN_PORTAL_DOMAIN}/login-tenant`
}

const generateRandomPassword = () => {
  return crypto.randomBytes(20).toString('hex');
}

const generateResetPasswordLink = async (authManager: Auth, userEmail: string): Promise<string> => {
  return new Promise(async (resolve, reject) => {
    try {
      const resetPasswordLink: string = await authManager.generatePasswordResetLink(userEmail, actionCodeSettings);
      resolve(resetPasswordLink);
    } catch (error) {
      reject(newErrorMessage(500, "generateResetPasswordLink", StatusCodes.internalServerError, error.message));
    }
  })
}

export const createTenantAdmin = async (payload: any): Promise<void> => {

  return new Promise(async (resolve, reject) => {

    try {

      const _ = new FirebaseService();

      const authManager = auth();

      await authManager.createUser({
        email: payload.email,
        emailVerified: false,
        password: generateRandomPassword(),
        disabled: false
      });

      const resetPasswordLink = await generateResetPasswordLink(authManager, payload.email);

      const emailService = new EmailService();
      const emailObject: EmailService.EmailObject = {
        to: payload.email,
        template: true,
        content: {
          name: "resetPassword",
          data: {
            link: resetPasswordLink
          }
        }
      }

      await emailService.sendEmail(emailObject);

      resolve();
    } catch (error) {
      reject(newErrorMessage(500, "createTenantAdmin", StatusCodes.internalServerError, error.message));
    }

  });

}