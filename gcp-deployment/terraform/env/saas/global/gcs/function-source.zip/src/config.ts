export enum RequestOperation {
	createTenantAdmin = "createTenantAdmin",
	updateTenancy = "updateTenancy",
	updateTenantInfo = "updateTenantInfo",
	initVendor = "initVendor",
	updateVendor = "updateVendor",
	tenantOnboardingStatus = "tenantOnboardingStatus",
	initTenantStatus = "initTenantStatus",
	apigeeCreds = "apigeeCreds",
	deleteTenant = "deleteTenant",
}

export enum StatusCodes {
	ok = 1,
	invalidOperation,
	invalidTenantOnboardingRequest,
	internalServerError,
	badRequest,
	unknown,
}
