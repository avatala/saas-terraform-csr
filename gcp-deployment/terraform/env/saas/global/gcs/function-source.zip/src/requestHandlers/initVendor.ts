import { StatusCodes } from "../config";
import {
  FirestoreDB,
  newErrorMessage,
//   createSubnets,
  createTemplate,
} from "../helperFunctions";

export const initVendor = async (payload: any): Promise<void> => {
	return new Promise(async (resolve, reject) => {
		try {
			const db: FirestoreDB = new FirestoreDB();
			// const subnets: createSubnets = new createSubnets();
			const mailTemplates: createTemplate = new createTemplate();

			// Get all vendor documents
			const vendorSnapshot: FirebaseFirestore.QuerySnapshot<FirebaseFirestore.DocumentData> =
				await db.getDocuments("vendor");

			// If vendor collection is not empty then throw error
			if (!vendorSnapshot.empty) {
				throw new Error(
					`Document vendor details already exists in the vendor collection.`
				);
			}

			// Get all vendor data from payload
			const vendorData = {
				defaultVendorName: payload.defaultVendorName,
				defaultVendorEmail: payload.defaultVendorEmail,
				defaultVendorOrgName: payload.defaultVendorOrgName,
				landingPageDataStudioUrl: payload.landingPageDataStudioUrl,
				costDataStudioUrl: payload.costDataStudioUrl,
				usageDataStudioUrl: payload.usageDataStudioUrl,
				asmDashboardUrl: payload.asmDashboardUrl,
				logMonDashboardUrl: payload.logMonDashboardUrl,
				updateFreemiumCloudBuildProjectLocation: payload.updateFreemiumCloudBuildProjectLocation,
				updateFreemiumCloudBuildTrigger: payload.updateFreemiumCloudBuildTrigger,
				idpEnterpriseCloudBuildTriggerlocation: payload.idpEnterpriseCloudBuildTriggerlocation,
				idpEnterpriseCloudBuildTrigger: payload.idpEnterpriseCloudBuildTrigger,
				cloudBuildProjectId: payload.cloudBuildProjectId,
				freemiumProjectId: payload.freemiumProjectId,
				freemiumCloudBuildTrigger: payload.freemiumCloudBuildTrigger,
				freemiumCloudBuildRepoName: payload.freemiumCloudBuildRepoName,
				freemiumCloudBuildBranchName:
					payload.freemiumCloudBuildBranchName,
				freemiumCloudBuildProjectLocation:
					payload.freemiumCloudBuildProjectLocation,
				enterpriseCloudBuildTrigger:
					payload.enterpriseCloudBuildTrigger,
				enterpriseCloudBuildRepoName:
					payload.enterpriseCloudBuildRepoName,
				enterpriseCloudBuildBranchName:
					payload.enterpriseCloudBuildBranchName,
				enterpriseCloudBuildProjectLocation:
					payload.enterpriseCloudBuildProjectLocation,
				deleteFreemiumCloudBuildTrigger:
					payload.deleteFreemiumCloudBuildTrigger,
				deleteFreemiumCloudBuildProjectLocation:
					payload.deleteFreemiumCloudBuildProjectLocation,
				deleteFreemiumCloudBuildRepoName:
					payload.deleteFreemiumCloudBuildRepoName,
				deleteFreemiumCloudBuildBranchName:
					payload.deleteFreemiumCloudBuildBranchName,
				deleteEnterpriseCloudBuildTrigger:
					payload.deleteEnterpriseCloudBuildTrigger,
				deleteEnterpriseCloudBuildProjectLocation:
					payload.deleteEnterpriseCloudBuildProjectLocation,
				deleteEnterpriseCloudBuildRepoName:
					payload.deleteEnterpriseCloudBuildRepoName,
				deleteEnterpriseCloudBuildBranchName:
					payload.deleteEnterpriseCloudBuildBranchName,
				freemiumSubdomain: payload.freemiumSubdomain,
				enterpriseSubdomain: payload.enterpriseSubdomain,
			};

			// Write vendor data into firestore
			await db.addDocument("vendor", vendorData);

			// Get vendor user data from payload
			const adminVendorUserData = {
				name: payload.defaultVendorName,
				email: payload.defaultVendorEmail,
				orgName: payload.defaultVendorOrgName,
				isAdmin: true,
			};

			// Check whether vendor user already exists based on email id
			const vendorUserSnapshot = await db.conditionalGetDocuments(
				"vendorUser",
				"email",
				"equal",
				payload.defaultVendorEmail
			);

			// if vendor user already exists then throw error
			if (!vendorUserSnapshot.empty) {
				throw new Error(
					`Document ${payload.defaultVendorEmail} already exists in the vendorUser collection.`
				);
			}

			// Write vendor user into firestore
			await db.addDocument("vendorUser", adminVendorUserData);

			// // Initialise small subnets
			// await db.batchWriteArrayOfObjectsInSubcollection(
			// 	"subnets",
			// 	"smallSubnets",
			// 	"smallSubnets",
			// 	subnets.smallTenant()
			// );

			// console.log("Added small subnets");

			// // Initialise medium subnets
			// await db.batchWriteArrayOfObjectsInSubcollection(
			// 	"subnets",
			// 	"mediumSubnets",
			// 	"mediumSubnets",
			// 	subnets.mediumTenant()
			// );

			// console.log("Added medium subnets");

			// // Initialise large subnets
			// await db.batchWriteArrayOfObjectsInSubcollection(
			// 	"subnets",
			// 	"largeSubnets",
			// 	"largeSubnets",
			// 	subnets.largeTenant()
			// );

			// console.log("Added large subnets");
			//set mail templates
			const setTemplate=mailTemplates.emailTempate()
			setTemplate.map(async current=>{
				console.log("Added EmailTemplate "+current.name)
				await db.addDocumentWithDocId("mailTemplates",current.name,current.content);
			})

			resolve();
		} catch (error) {
			reject(
				newErrorMessage(
					500,
					"initVendor",
					StatusCodes.unknown,
					error.message
				)
			);
		}
	});
};
