import * as yup from "yup";
import { requestPayload } from "./base";

export const updateTenancyRequest = yup.object({
  tenantId: yup.string().required(),
  ipTenantId: yup.string().required(),
}).concat(requestPayload);