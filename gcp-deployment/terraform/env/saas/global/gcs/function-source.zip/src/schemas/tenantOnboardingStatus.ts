import * as yup from "yup";
import { requestPayload } from "./base";

export const tenantOnboardingStatusRequest = yup
	.object({
		subdomain: yup.string().required(),
		projectId: yup.string().required(),
		triggerId: yup.string().required(),
		stage: yup.number().required(),
		totalStages: yup.number().required(),
		location: yup.string().required()
	})
	.concat(requestPayload);
