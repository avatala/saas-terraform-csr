import * as yup from "yup";
import { requestPayload } from "./base";

export const createTenantAdminRequest = yup
	.object({
		email: yup.string().required(),
	})
	.concat(requestPayload);
