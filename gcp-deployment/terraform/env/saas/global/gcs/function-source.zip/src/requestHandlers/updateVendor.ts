// internal imports
import { StatusCodes } from "../config";
import { FirestoreDB, newErrorMessage } from "../helperFunctions";


export const updateVendor = async (payload: any): Promise<void> => {
	return new Promise(async (resolve, reject) => {
		try {
			const db = new FirestoreDB();
			
			await db.conditionalUpdateDocument(
				"vendor",
				"defaultVendorEmail",
				"equal",
				payload.defaultVendorEmail,
				{ callbackUrl: payload.callbackUrl }
			);

			console.log(
				`Vendor updated with callbackUrl ${payload.callbackUrl} successfully`
			);

			resolve();
		} catch (error) {

			reject(newErrorMessage(500, "updateVendor", StatusCodes.internalServerError, error.message));

		}
	});
};
