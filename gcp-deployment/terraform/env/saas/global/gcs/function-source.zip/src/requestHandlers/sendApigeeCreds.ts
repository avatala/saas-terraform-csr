// module imports
import { newErrorMessage } from "../helperFunctions";
import { StatusCodes } from "../config";
import { EmailService } from "../helperFunctions";

export const sendApigeeCreds = async (payload: any): Promise<void> => {

  return new Promise(async (resolve, reject) => {

    try {

      const emailService = new EmailService();
      const emailObject: EmailService.EmailObject = {
        to: payload.email,
        template: true,
        content: {
          name: "apigeeCreds",
          data: {
            appKey: payload.appKey,
            appSecret: payload.appSecret,
            host: payload.host
          }
        }
      }

      await emailService.sendEmail(emailObject);

      resolve();
    } catch (error) {
      reject(newErrorMessage(500, "sendApigeeCreds", StatusCodes.internalServerError, error.message));
    }

  });

}