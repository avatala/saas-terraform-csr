import { CBClient, FirestoreDB, newErrorMessage } from "../helperFunctions";
import { StatusCodes } from "../config";
import { Tiers } from "../types";

export const runTrigger = async (subdomain: string): Promise<void> => {
	return new Promise(async (resolve, reject) => {
		try {
			const db = new FirestoreDB();
			const tenantData = await db.conditionalGetDocuments(
				"tenant",
				"subdomain",
				"equal",
				subdomain
			);

			if (tenantData.empty) {
				throw new Error(
					`Document ${subdomain} is not exists in the tenant collection.hello world`
				);
			}

			// Extract the data of the first document in the snapshot
			const tenantDocData = tenantData.docs[0].data();

			// Read the value of the "tier" field
			const tier: string = tenantDocData.tier;

			const cb = new CBClient();

			db.conditionalUpdateDocument(
				"tenant",
				"subdomain",
				"equal",
				subdomain,
				{ emailVerified: true }
			);
			console.log(`Email Verified for subdomain ${subdomain}`);

			switch (tier) {
				case Tiers.enterprise:
        try{
          // console.log("tenantDocData, runTrigger",JSON.stringify(tenantDocData))
					await cb.runBuildTrigger("create", tier, {
						_CUSTOMER_EMAIL: tenantDocData.adminEmail,
						_CUSTOMER_NAME: tenantDocData.subdomain,
						_TENANT_ID: tenantDocData.subdomain,
						_REGION: tenantDocData.gcpRegion,
						_ENTERPRISE_PROJECT_ID: tenantDocData.projectId,
						_ENTERPRISE_BQ_DATASET_ID: tenantDocData.bqDatasetId,
						_MACHINE_TYPE: tenantDocData.machineType,
						_ZONE: tenantDocData.zone,
						_MIN_COUNT: tenantDocData.minCount,
						_MAX_COUNT: tenantDocData.maxCount,
						_NODE_COUNT: tenantDocData.nodeCount,
						_MASTER_IP: tenantDocData.masterIp,
						_SUBNET_IP: tenantDocData.subnetIp,
						_POD_RANGE: tenantDocData.podIp,
						_SVC_RANGE: tenantDocData.svcIp,
						_ORG_LOGO_URL: tenantDocData.logoUrl,
						_TENANT_DOMAIN: tenantDocData.domain,
						_PORT: tenantDocData.port,
            _ACCELERATOR_TYPE: tenantDocData.gpuType,
						_ACCELERATOR_COUNT: tenantDocData.gpuCount
					});
					console.log("Enterprise build triggerred successfully");
          }
          catch(e){
            console.log(`Error form runBuildTrigger,${tier}`)
            console.log(e)
          }
					break;
				case Tiers.freemium:
          try{
            await cb.runBuildTrigger("create", tier, {
              _CUSTOMER_EMAIL: tenantDocData.adminEmail,
              _CUSTOMER_NAME: tenantDocData.subdomain,
              _TENANT_ID: tenantDocData.subdomain,
              _ORG_LOGO_URL: tenantDocData.logoUrl,
              _TENANT_DOMAIN: tenantDocData.domain,
              _PORT: tenantDocData.port,
            });
            console.log("Freemium build triggerred successfully");
          }
          catch(e){
            console.log(`Error form runBuildTrigger,${tier}`)
            console.log(e)
          }
					break;
				default:
					throw new Error(
						`Internal server error. Tenant Onboarding for ${subdomain} failed. Couldn't find appropriate tier for the Tenant.`
					);
			}

			resolve();
		} catch (error) {
			reject(
				newErrorMessage(
					500,
					"runTrigger",
					StatusCodes.internalServerError,
					error.message
				)
			);
		}
	});
};
