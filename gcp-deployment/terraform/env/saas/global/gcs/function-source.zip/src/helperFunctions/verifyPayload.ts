// internal imports
import { RequestOperation, StatusCodes } from "../config";
import {
	createTenantAdminRequest,
	updateTenancyRequest,
	updateTenantInfoRequest,
	initVendorRequest,
	updateVendorRequest,
	tenantOnboardingStatusRequest,
	initTenantStatusRequest,
	sendApigeeCredsRequest,
	deleteTenantRequest,
} from "../schemas";
import {
	CreateTenantAdminRequest,
	UpdateTenancyRequest,
	UpdateTenantInfoRequest,
	InitVendorRequest,
	UpdateVendorRequest,
	TenantOnboardingStatusRequest,
	InitTenantStatusRequest,
	SendApigeeCredsRequest,
	DeleteTenantRequest,
} from "../types";
import { newErrorMessage } from "./newErrorMessage";

export const verifyPayload = (
	payload:
		| CreateTenantAdminRequest
		| UpdateTenancyRequest
		| UpdateTenantInfoRequest
		| InitVendorRequest
		| UpdateVendorRequest
		| TenantOnboardingStatusRequest
		| InitTenantStatusRequest
		| SendApigeeCredsRequest
		| DeleteTenantRequest
): Promise<StatusCodes | void> => {
	return new Promise(async (resolve, reject) => {
		try {
			switch (payload.operation) {
				case RequestOperation.createTenantAdmin:
					await createTenantAdminRequest.validate(payload, {
						strict: true,
					});
					resolve();
					break;

				case RequestOperation.updateTenancy:
					await updateTenancyRequest.validate(payload, {
						strict: true,
					});
					resolve();
					break;

				case RequestOperation.updateTenantInfo:
					await updateTenantInfoRequest.validate(payload, {
						strict: true,
					});
					resolve();
					break;

				case RequestOperation.initVendor:
					await initVendorRequest.validate(payload, { strict: true });
					resolve();
					break;

				case RequestOperation.updateVendor:
					await updateVendorRequest.validate(payload, {
						strict: true,
					});
					resolve();
					break;

				case RequestOperation.tenantOnboardingStatus:
					await tenantOnboardingStatusRequest.validate(payload, {
						strict: true,
					});
					resolve();
					break;
				case RequestOperation.initTenantStatus:
					await initTenantStatusRequest.validate(payload, {
						strict: true,
					});
					resolve();
					break;
				case RequestOperation.deleteTenant:
					await deleteTenantRequest.validate(payload, {
						strict: true,
					});
					resolve();
					break;
				case RequestOperation.apigeeCreds:
					await sendApigeeCredsRequest.validate(payload, {
						strict: true,
					});
					resolve();
					break;

				default:
					reject(
						newErrorMessage(
							400,
							"verifyPayload",
							StatusCodes.invalidOperation,
							"Bad Request. Invalid operation arguement."
						)
					);
			}
		} catch (error) {
			reject(
				newErrorMessage(
					400,
					"verifyPayload",
					StatusCodes.badRequest,
					error.message
				)
			);
		}
	});
};
