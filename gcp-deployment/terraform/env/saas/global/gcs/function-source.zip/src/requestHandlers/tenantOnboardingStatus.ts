// module imports
import { CBClient, EmailService } from "../helperFunctions";
import { FirestoreDB, newErrorMessage } from "../helperFunctions";
import { StatusCodes } from "../config";
import { BuildStatusData } from "../types";

export const tenantOnboardingStatus = async (payload: any): Promise<void> => {
	return new Promise(async (resolve, reject) => {
		try {
			// Get FirestoreDB class
			const db: FirestoreDB = new FirestoreDB();

			// Get tenant document based on subdomain
			let tenantSnapshot: FirebaseFirestore.QuerySnapshot<FirebaseFirestore.DocumentData> =
				await db.conditionalGetDocuments(
					"tenant",
					"subdomain",
					"equal",
					payload.subdomain
				);

			//Throw error if subdomain is invalid
			if (tenantSnapshot.empty) {
				throw new Error(
					`Document ${payload.subdomain} does not exist in the tenant collection.`
				);
			}

			// Get all vendor documents
			let vendorSnapshot: FirebaseFirestore.QuerySnapshot<FirebaseFirestore.DocumentData> =
				await db.getDocuments("vendor");

			// If vendor collection is not empty then throw error
			if (vendorSnapshot.empty) {
				throw new Error(`No Document exists in the vendor collection.`);
			}

			// Get StatusArray
			let buildStatusArray =
				db.getArrayOfDocs(tenantSnapshot)[0].statusArray;

			const cb = new CBClient();

			// Initialise currBuildStatus
			let currBuildStatus = await cb.getBuildStatus(
				payload.projectId,
				payload.location,
				payload.triggerId
			);

			// Initialise currentBuildStatus
			let currBuildStatusData: BuildStatusData = {
				buildTitle: buildStatusArray[payload.stage].buildTitle,
				groupTitle: buildStatusArray[payload.stage].groupTitle,
				id: currBuildStatus.id,
				status: currBuildStatus.status,
				startTime: currBuildStatus.startTime?.seconds
					? db.toFirestoreTimestamp(
							Number(currBuildStatus.startTime.seconds),
							Number(currBuildStatus.startTime.nanos)
					  )
					: null,
				finishTime: currBuildStatus.finishTime?.seconds
					? db.toFirestoreTimestamp(
							Number(currBuildStatus.finishTime.seconds),
							Number(currBuildStatus.finishTime.nanos)
					  )
					: null,
				sourceRepo: currBuildStatus.source.repoSource.repoName,
				logUrl: currBuildStatus.logUrl,
			};

			// Update WORKING STATUS to Firestore
			// Append data to stage index
			buildStatusArray[payload.stage] = currBuildStatusData;

			// Update statusArray in Firestore
			await db.conditionalUpdateDocument(
				"tenant",
				"subdomain",
				"equal",
				payload.subdomain,
				{ statusArray: buildStatusArray }
			);

			// Keep checking current build status until status is "WORKING"
			let checkStatusInIntervals = async () => {
				if (currBuildStatus.status !== "WORKING") {
					clearInterval(getBuildStatusInterval);

					currBuildStatus = await cb.getBuildStatus(
						payload.projectId,
						payload.location,
						payload.triggerId
					);

					// Get required data from Build Status response
					currBuildStatusData = {
						buildTitle: buildStatusArray[payload.stage].buildTitle,
						groupTitle: buildStatusArray[payload.stage].groupTitle,
						id: currBuildStatus.id,
						status: currBuildStatus.status,
						startTime: currBuildStatus.startTime?.seconds
							? db.toFirestoreTimestamp(
									Number(currBuildStatus.startTime.seconds),
									Number(currBuildStatus.startTime.nanos)
							  )
							: null,
						finishTime: currBuildStatus.finishTime?.seconds
							? db.toFirestoreTimestamp(
									Number(currBuildStatus.finishTime.seconds),
									Number(currBuildStatus.finishTime.nanos)
							  )
							: null,
						sourceRepo: currBuildStatus.source.repoSource.repoName,
						logUrl: currBuildStatus.logUrl,
					};

					// In case build fails get failure information
					if (currBuildStatus.status === "FAILURE") {
						currBuildStatusData.failureInfo = {
							type: currBuildStatus.failureInfo.type,
							detail: currBuildStatus.failureInfo.detail,
						};

						const vendorEmail: string =
							db.getArrayOfDocs(vendorSnapshot)[0]
								.defaultVendorEmail; // default vendor
						const emailService = new EmailService();
						const emailObject: EmailService.EmailObject = {
							to: vendorEmail,
							template: true,
							content: {
								name: "tenantOnboardFailure",
								data: {
									errorType: currBuildStatus.failureInfo.type,
									errorDetails:
										currBuildStatus.failureInfo.detail,
									logUrl: currBuildStatus.logUrl,
									subdomain: payload.subdomain,
								},
							},
						};
						// Send Tenant Onboarded Failure Email
						await emailService.sendEmail(emailObject);
					}

					// Append data to stage index
					buildStatusArray[payload.stage] = currBuildStatusData;

					// Update statusArray in Firestore
					await db.conditionalUpdateDocument(
						"tenant",
						"subdomain",
						"equal",
						payload.subdomain,
						{ statusArray: buildStatusArray }
					);

					//Check whether payload.stage == payload.totalStages-1 and send email
					if (payload.stage === payload.totalStages - 1) {
						const tenantEmail: string =
							db.getArrayOfDocs(tenantSnapshot)[0].adminEmail;
						const tenantDomain: string =
							"https://" +
							db.getArrayOfDocs(tenantSnapshot)[0].domain;
						const tenantSubdomain: string =
							db.getArrayOfDocs(tenantSnapshot)[0].subdomain;
						const tenantTier: string =
							db.getArrayOfDocs(tenantSnapshot)[0].tier;
						const emailService = new EmailService();
						const emailObject: EmailService.EmailObject = {
							to: tenantEmail,
							template: true,
							content: {
								name: "tenantSuccessfullyOnboarded",
								data: {
									domain: tenantDomain,
									subdomain: tenantSubdomain,
									tier: tenantTier,
								},
							},
						};
						//Send Tenant successfully onboarded email to tenant
						await emailService.sendEmail(emailObject);

						//Send Tenant successfully onboarded email to vendor
						const vendorEmail: string =
							db.getArrayOfDocs(vendorSnapshot)[0]
								.defaultVendorEmail; //default vendor

						const vendorEmailObject: EmailService.EmailObject = {
							to: vendorEmail,
							template: true,
							content: {
								name: "tenantSuccessfullyOnboarded",
								data: {
									domain: tenantDomain,
									subdomain: tenantSubdomain,
									tier: tenantTier,
								},
							},
						};
						//Send Tenant successfully onboarded email
						await emailService.sendEmail(vendorEmailObject);
					}
				}
				try {
					currBuildStatus = await cb.getBuildStatus(
						payload.projectId,
						payload.location,
						payload.triggerId
					);

					console.log(
						"Build id " +
							payload?.triggerId +
							" is in " +
							currBuildStatus.status +
							" status for subdomain:" +
							payload?.subdomain
					);
				} catch (error) {
					reject(
						newErrorMessage(
							500,
							"tenantOnboardingStatus",
							StatusCodes.internalServerError,
							error.message
						)
					);
				}
			};

			const getBuildStatusInterval = setInterval(
				checkStatusInIntervals,
				10000
			);

			//Check status
			await checkStatusInIntervals();

			resolve();
		} catch (error) {
			reject(
				newErrorMessage(
					500,
					"tenantOnboardingStatus",
					StatusCodes.unknown,
					error.message
				)
			);
		}
	});
};
