import { FirestoreDB } from "./firestore";


export class EmailService {

  firestore: FirestoreDB;
  emailCollectionName: string;
  templateCollectionName: string;

  constructor() {
    this.firestore = new FirestoreDB();
    this.emailCollectionName = "mails";
    this.templateCollectionName = "mailTemplates";
  }

  async sendEmail(emailObject: EmailService.EmailObject): Promise<void> {
    return new Promise(async (resolve, reject) => {
      try {
        switch (emailObject.template) {
          case true:
            await this.firestore.addDocument(this.emailCollectionName, {
              to: emailObject.to,
              template: emailObject.content
            });
            break;
          case false:
            await this.firestore.addDocument(this.emailCollectionName, {
              to: emailObject.to,
              message: emailObject.content
            });
            break;
          default:
            throw new Error("template is a boolean and can only be either true or false.");
            break;
        }
        resolve();
      } catch (error) {
        reject(error.message);
      }
    })
  }
}

export namespace EmailService {
  type messageObject = {
    subject: string;
    html?: string;
    text?: string;
  };
  type templateObject = {
    name: string;
    data?: { [k: string]: any };
  }
  export interface EmailObject {
    to: string;
    template: boolean;
    content: messageObject | templateObject;
  }
}