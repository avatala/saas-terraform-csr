// module imports
import { InferType } from "yup";
import { google } from "@google-cloud/cloudbuild/build/protos/protos";

// internal imports
import {
	createTenantAdminRequest,
	initVendorRequest,
	tenantOnboardingStatusRequest,
	updateTenancyRequest,
	updateTenantInfoRequest,
	initTenantStatusRequest,
	sendApigeeCredsRequest,
	updateVendorRequest,
	deleteTenantRequest,
} from "./schemas";

export enum WhereOperations {
	"equal" = "==",
	"greaterThan" = ">",
	"lessThan" = "<",
	"greaterThanEqual" = ">=",
	"lessThanEqual" = "<=",
}

export enum BuildStatus {
	"STATUS_UNKNOWN" = 3,
	"PENDING" = 3,
	"QUEUED" = 0,
	"WORKING" = 3,
	"SUCCESS" = 1,
	"FAILURE" = 2,
	"INTERNAL_ERROR" = 3,
	"TIMEOUT" = 3,
	"CANCELLED" = 3,
	"EXPIRED" = 3,
	"null" = 3,
	"undefined" = 3,
}

export type BuildStatusData = {
	buildTitle: string;
	groupTitle: string;
	id?: string | null;
	status?:
		| google.devtools.cloudbuild.v1.Build.Status
		| keyof typeof google.devtools.cloudbuild.v1.Build.Status
		| null;
	startTime: FirebaseFirestore.Timestamp | null;
	finishTime: FirebaseFirestore.Timestamp | null;
	sourceRepo?: string | null;
	logUrl?: string | null;
	failureInfo?: {
		detail?: string | null;
		type?:
			| google.devtools.cloudbuild.v1.Build.FailureInfo.FailureType
			| keyof typeof google.devtools.cloudbuild.v1.Build.FailureInfo.FailureType
			| null;
	};
};

export type SubnetData = {
	subnetIp: string;
	masterIp: string;
	podIp: string;
	svcIp: string;
	maxCount: Number;
	minCount: Number;
	nodeCount: Number;
	machineType: string;
	tenantId: null | string;
	subnetId: string;
};

export type UpdateTenancyRequest = InferType<typeof updateTenancyRequest>;
export type UpdateTenantInfoRequest = InferType<typeof updateTenantInfoRequest>;
export type CreateTenantAdminRequest = InferType<
	typeof createTenantAdminRequest
>;
export type InitVendorRequest = InferType<typeof initVendorRequest>;
export type DeleteTenantRequest = InferType<typeof deleteTenantRequest>;
export type UpdateVendorRequest = InferType<typeof updateVendorRequest>;
export type InitTenantStatusRequest = InferType<typeof initTenantStatusRequest>;
export type TenantOnboardingStatusRequest = InferType<
	typeof tenantOnboardingStatusRequest
>;
export type SendApigeeCredsRequest = InferType<typeof sendApigeeCredsRequest>;

export type ErrorMessage = {
	status: number;
	message: string;
};

export enum Operations {
	create = "create",
	delete = "delete",
}

export enum Tiers {
	freemium = "freemium",
	enterprise = "enterprise",
}

export type emailTemplate = {
	name: string;
	content: {
		subject: string;
		html: string;
	};
};
