import * as yup from "yup";
import { requestPayload } from "./base";

export const initTenantStatusRequest = yup
	.object({
		subdomain: yup.string().required(),
		buildTitleArray: yup.array().required(),
	})
	.concat(requestPayload);
