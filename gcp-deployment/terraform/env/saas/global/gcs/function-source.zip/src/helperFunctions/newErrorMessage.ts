import { StatusCodes } from "../config";
import { ErrorMessage } from "../types";

export const newErrorMessage = (httpStatus: number, functionName: string, statusCode: StatusCodes, message: any): ErrorMessage => {
  const errorMessage = {
    status: httpStatus,
    message: `${functionName} | Error Code : ${statusCode} | Error Message : ${message}`
  };

  return errorMessage;
}