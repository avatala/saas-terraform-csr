import { emailTemplate } from "../types";

export class createTemplate {
	// create mail template
	emailTempate = (): Array<emailTemplate> => {
		const templates: Array<emailTemplate> = [];

		let tenantSuccessfullyOnboarded: emailTemplate = {
			name: "tenantSuccessfullyOnboarded",
			content: {
				subject: "Tenant Onboarding Successfully",
				html: `<!DOCTYPE html><html lang="en"><head> <meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0"> <style> /* CSS styles for the email */ body { font-family: Arial, sans-serif; line-height: 1.4; } .container { max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f5f5f5; border-radius: 8px; } .board { background-color: #ffffff; border: 1px solid #cccccc; padding: 20px; border-radius: 4px; } h1 { color: #333; font-size: 24px; margin-bottom: 20px; } p { margin-bottom: 10px; } .highlight { color: #ff9900; font-weight: bold; } .footer { margin-top: 20px; text-align: center; font-size: 12px; color: #777; } </style></head><body> <div class="container"> <div class="board"> <h1>Welcome to our platform!</h1> <p>Congratulations! Your tenant onboarding was successful.</p> <p>Here are the details:</p> <ul> <li><strong>Domain Name:</strong> <span class="highlight">{{domain}}</span></li> <li><strong>Subdomain Name:</strong> <span class="highlight">{{subdomain}}</span></li> <li><strong>Tier:</strong> <span class="highlight">{{tier}}</span></li> </ul> <p>If you have any questions or need assistance, please feel free to reach out to our support.</p> <p>Thank you and enjoy using our platform!</p> </div> <div class="footer"> <p>This email was sent to you as an acknowledgement to your request.</p> </div> </div></body></html>`,
			},
		};
		templates.push(tenantSuccessfullyOnboarded);

		let tenantOnboardFailure: emailTemplate = {
			name: "tenantOnboardFailure",
			content: {
				subject: "Tenant Onboarding Failed",
				html: `<!DOCTYPE html><html lang="en"><head> <meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0"> <style> /* CSS styles for the email */ body { font-family: Arial, sans-serif; line-height: 1.4; } .container { max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f5f5f5; border-radius: 8px; } .board { background-color: #ffffff; border: 1px solid #cccccc; padding: 20px; border-radius: 4px; } h1 { color: #333; font-size: 24px; margin-bottom: 20px; } p { margin-bottom: 10px; } .highlight { color: #ff9900; font-weight: bold; } .prompt { margin-top: 20px; font-size: 16px; font-weight: bold; } .footer { margin-top: 20px; text-align: center; font-size: 12px; color: #777; } </style></head><body> <div class="container"> <div class="board"> <h1>Tenant Onboard Failure</h1> <p>We apologize for the inconvenience, but we were unable to complete your tenant onboarding process for <b>{{subdomain}}</b> at this time.</p> <div class="prompt"> <p>Kindly include the following details:</p> <ul> <li><strong>Error Type:</strong> <span class="highlight">{{errorType}}</span></li> <li><strong>Error Details:</strong> <span class="highlight">{{errorDetails}}</span></li> <li><strong>Build Logs:</strong> <span class="highlight">{{logUrl}}</span></li> </ul> </div> <p>We apologize for any inconvenience caused, and we will work to resolve the issue promptly.</p> </div> <div class="footer"> <p>This email was sent to you as an acknowledgement to your request.</p> </div> </div></body></html>`,
			},
		};
		templates.push(tenantOnboardFailure);

		let resetPassword: emailTemplate = {
			name: "resetPassword",
			content: {
				subject: "Reset Password Request",
				html: `<!DOCTYPE html><html lang="en"> <head> <meta charset="UTF-8" /> <meta name="viewport" content="width=device-width, initial-scale=1.0" /> <style> /* CSS styles for the email */ body { font-family: Arial, sans-serif; line-height: 1.4; } .container { max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f5f5f5; border-radius: 8px; } .board { background-color: #ffffff; border: 1px solid #cccccc; padding: 20px; border-radius: 4px; } h1 { color: #333; font-size: 24px; margin-bottom: 20px; } p { margin-bottom: 10px; } .highlight { color: #ff9900; font-weight: bold; } .reset-link { display: inline-block; background-color: #007bff; color: #ffffff; text-decoration: none; padding: 10px 20px; border-radius: 4px; } .footer { margin-top: 20px; text-align: center; font-size: 12px; color: #777; } </style> </head> <body> <div class="container"> <div class="board"> <h1>Password Reset</h1> <p>We request you to reset your password as per our onboard process.</p> <p>To reset your password, please click on the link below:</p> <p><a href="{{link}}" class="reset-link">Reset Password</a></p> <p> If you did not request a password reset, please ignore this email. </p> </div> <div class="footer"> <p>This email was sent to you as an acknowledgement to your request.</p> </div> </div> </body></html>`,
			},
		};
		templates.push(resetPassword);

		let apigeeCredsMail: emailTemplate = {
			name: "apigeeCreds",
			content: {
				subject: "Apigee Credentials",
				html: `<!DOCTYPE html><html lang="en"><head> <meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0"> <style> /* CSS styles for the email */ body { font-family: Arial, sans-serif; line-height: 1.4; } .container { max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f5f5f5; border-radius: 8px; } .board { background-color: #ffffff; border: 1px solid #cccccc; padding: 20px; border-radius: 4px; } h1 { color: #333; font-size: 24px; margin-bottom: 20px; } p { margin-bottom: 10px; } .highlight { color: #ff9900; font-weight: bold; } .footer { margin-top: 20px; text-align: center; font-size: 12px; color: #777; } </style></head><body> <div class="container"> <div class="board"> <h1>Your Apigee Tenant Credentials</h1> <p>Here are your Apigee credentials:</p> <ul> <li><strong>App Key:</strong> <span class="highlight">{{appKey}}</span></li> <li><strong>App Secret:</strong> <span class="highlight">{{appSecret}}</span></li> <li><strong>Host:</strong> <span class="highlight">{{host}}</span></li> </ul> <p>Please keep these credentials secure, as they will be required for API integration and management.</p> <p>If you have any questions or need assistance, please don't hesitate to reach us.</p> <p>Thank you</p> </div> <div class="footer"> <p>This email was sent to you as an acknowledgement to your request.</p> </div> </div></body></html>`,
			},
		};
		templates.push(apigeeCredsMail);

		let onboardInitializeEmail: emailTemplate = {
			name: "onboardInitializeEmail",
			content: {
				subject: "Email Verification",
				html: `<!DOCTYPE html><html lang="en"><head> <meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0"> <style> /* CSS styles for the email */ body { font-family: Arial, sans-serif; line-height: 1.4; } .container { max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f5f5f5; border-radius: 8px; } .board { background-color: #ffffff; border: 1px solid #cccccc; padding: 20px; border-radius: 4px; } h1 { color: #333; font-size: 24px; margin-bottom: 20px; } p { margin-bottom: 10px; } .highlight { color: #ff9900; font-weight: bold; } .button { display: inline-block; background-color: #007bff; color: #ffffff; text-decoration: none; padding: 10px 20px; border-radius: 4px; } .footer { margin-top: 20px; text-align: center; font-size: 12px; color: #777; } </style></head><body> <div class="container"> <div class="board"> <h1>Welcome, {{orgName}}</h1> <p>Thank you for choosing our services! We are excited to have you onboard.</p> <p>To start the onboard process, please verify your email by clicking the button below:</p> <p><a href="{{onboardUrl}}/?subdomain={{subDomain}}" class="button">Verify</a></p> <p>If you have any questions or need assistance, please don't hesitate to write us.</p> <p>We look forward to serving you!</p> </div> <div class="footer"> <p>This email was sent to you as an acknowledgement to your request.</p> </div> </div></body></html>`,
			},
		};
		templates.push(onboardInitializeEmail);
		return templates;
	};
}
