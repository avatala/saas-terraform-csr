// module imports
import { FirestoreDB, newErrorMessage } from "../helperFunctions";
import { StatusCodes } from "../config";

export const initTenantStatus = async (payload: any): Promise<void> => {
	return new Promise(async (resolve, reject) => {
		try {
			// let buildTitleArray = [
			// 	{ buildTitle: "build1", groupTitle: "group1" },
			// 	{ buildTitle: "build2", groupTitle: "group1" },
			// 	{ buildTitle: "build2", groupTitle: "group2" },
			// 	{ buildTitle: "build1", groupTitle: "group2" },
			// ];

			// Get FirestoreDB class
			const db: FirestoreDB = new FirestoreDB();

			// Get tenant document based on subdomain
			let tenantSnapshot: FirebaseFirestore.QuerySnapshot<FirebaseFirestore.DocumentData> =
				await db.conditionalGetDocuments(
					"tenant",
					"subdomain",
					"equal",
					payload.subdomain
				);

			//Throw error if subdomain is invalid
			if (tenantSnapshot.empty) {
				throw new Error(
					`Document ${payload.subdomain} does not exist in the tenant collection.`
				);
			}

			//Initialise statusArray
			let initStatusArray = payload.buildTitleArray.map(
				(element: { buildTitle: string; groupTitle: string }) => ({
					buildTitle: element.buildTitle,
					groupTitle: element.groupTitle,
					status: "PENDING",
				})
			);

			await db.conditionalUpdateDocument(
				"tenant",
				"subdomain",
				"equal",
				payload.subdomain,
				{ statusArray: initStatusArray }
			);

			resolve();
		} catch (error) {
			reject(
				newErrorMessage(
					500,
					"tenantOnboardingStatus",
					StatusCodes.unknown,
					error.message
				)
			);
		}
	});
};
