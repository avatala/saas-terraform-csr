import * as yup from "yup";
import { requestPayload } from "./base";

export const updateVendorRequest = yup
	.object({
		defaultVendorEmail: yup.string().required(),
		callbackUrl: yup.string().required(),
	})
	.concat(requestPayload);
