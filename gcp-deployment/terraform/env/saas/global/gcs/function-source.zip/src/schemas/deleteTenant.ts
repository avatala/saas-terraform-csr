import * as yup from "yup";
import { requestPayload } from "./base";

export const deleteTenantRequest = yup
	.object({
		tenantId: yup.string().required(),
	})
	.concat(requestPayload);
