// internal imports
import { StatusCodes } from "../config";
import { FirestoreDB, newErrorMessage } from "../helperFunctions";
import { IdentityPlatform } from "../helperFunctions/identityPlatform";

export const deleteTenant = async (payload: any): Promise<void> => {
	return new Promise(async (resolve, reject) => {
		try {
			const db = new FirestoreDB();

			if (!payload.tenantId) {
				console.log(
					"Tenant subdomain is not provided, failed to delete tenant"
				);
			}

			const tenantSnapshot: FirebaseFirestore.QuerySnapshot<FirebaseFirestore.DocumentData> =
				await db.conditionalGetDocuments(
					"tenant",
					"subdomain",
					"equal",
					payload.tenantId
				);

			const adminEmail: string =
				db.getArrayOfDocs(tenantSnapshot)[0].adminEmail;

			//Throw error if subdomain is invalid
			if (tenantSnapshot.empty) {
				throw new Error(
					`Document ${payload.tenantId} does not exist in the tenant collection.`
				);
			}

			// if (payload.tier === "enterprise") {
			// 	//getting the subnetsize document reference and deallocating the tenant from its subnet
			// 	var subnetSize: string = subnetSizeDocRef(
			// 		payload.subnetSize
			// 	);
			// 	await db.conditionalUpdateDocumentWithinSubCollection(
			// 		"subnets",
			// 		subnetSize,
			// 		subnetSize,
			// 		"tenantId",
			// 		"equal",
			// 		payload.tenantId,
			// 		{
			// 			tenantId: null,
			// 		}
			// 	);
			// }

			await db.conditionalDeleteDocument(
				"tenantUser",
				"subdomain",
				"equal",
				payload.tenantId
			);

			await db.conditionalDeleteDocument(
				"tenant",
				"subdomain",
				"equal",
				payload.tenantId
			);

			//TODO: Check whether Identity Platform contains the user then delete
			const identityPlatform = new IdentityPlatform();
			await identityPlatform.deleteUser(adminEmail);

			resolve();
		} catch (error) {
			reject(
				newErrorMessage(
					500,
					"deleteTenant",
					StatusCodes.internalServerError,
					error.message
				)
			);
		}
	});
};
