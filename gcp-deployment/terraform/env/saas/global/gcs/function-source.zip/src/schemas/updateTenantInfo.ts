import * as yup from "yup";
import { requestPayload } from "./base";

export const updateTenantInfoRequest = yup
	.object({
		tenantId: yup.string().required(),
		info: yup.object().required(),
	})
	.concat(requestPayload);
