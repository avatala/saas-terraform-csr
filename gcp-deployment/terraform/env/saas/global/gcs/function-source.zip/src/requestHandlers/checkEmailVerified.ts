// internal imports
import { StatusCodes } from "../config";
import { FirestoreDB, newErrorMessage } from "../helperFunctions";

export const checkEmailVerified = async (
	subdomain: string
): Promise<boolean> => {
	return new Promise(async (resolve, reject) => {
		try {
			const db = new FirestoreDB();

			// Get tenant document based on subdomain
			let tenantSnapshot: FirebaseFirestore.QuerySnapshot<FirebaseFirestore.DocumentData> =
				await db.conditionalGetDocuments(
					"tenant",
					"subdomain",
					"equal",
					subdomain
				);

			//Throw error if subdomain is invalid
			if (tenantSnapshot.empty) {
				throw new Error(
					`Document ${subdomain} does not exist in the tenant collection.`
				);
			}

			if (!db.getArrayOfDocs(tenantSnapshot)[0].emailVerified) {
				console.log(`Email not Verified for subdomain ${subdomain}`);
			} else {
				console.log(
					`Email Already Verified for subdomain ${subdomain}`
				);
				resolve(false);
			}
			resolve(true);
		} catch (error) {
			reject(
				newErrorMessage(
					500,
					"checkEmailVerified",
					StatusCodes.internalServerError,
					error.message
				)
			);
		}
	});
};
