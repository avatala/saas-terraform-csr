import * as yup from "yup";
import { requestPayload } from "./base";

export const sendApigeeCredsRequest = yup
  .object({
    email: yup.string().required(),
    appKey: yup.string().required(),
    appSecret: yup.string().required(),
    host: yup.string().required(),
    devportalHost: yup.string().optional()
  })
  .concat(requestPayload);
