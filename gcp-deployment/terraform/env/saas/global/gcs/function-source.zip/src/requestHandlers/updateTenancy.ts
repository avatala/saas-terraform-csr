// internal imports
import { StatusCodes } from "../config";
import { FirestoreDB, newErrorMessage } from "../helperFunctions";
import { WhereOperations } from "../types";


export const updateTenancy = async (payload: any): Promise<void> => {

  return new Promise(async (resolve, reject) => {

    try {
      const db = new FirestoreDB();

      await db.conditionalUpdateDocument("tenant", "subdomain", "equal", payload.tenantId, { ipTenantId: payload.ipTenantId });

      resolve();
    } catch (error) {
      reject(newErrorMessage(500, "updateTenancy", StatusCodes.internalServerError, error.message));
    }

  });

}