import { AuthProviderConfig, TenantAwareAuth, TenantManager } from "firebase-admin/auth";
import { auth } from 'firebase-admin';

export class IdentityPlatform {
  private tenantAuthManager: TenantManager;

  constructor() {
    this.tenantAuthManager = auth().tenantManager();
  }

  private getTenantAuth(ipTenantId: string): TenantAwareAuth {
    return this.tenantAuthManager.authForTenant(ipTenantId);
  }

  async listConfigurations(ipTenantId: string): Promise<Array<AuthProviderConfig>> {
    return new Promise(async (resolve, reject) => {
      try {
        const tenantAuth = this.getTenantAuth(ipTenantId);

        const { providerConfigs: samlProviderConfigs } = await tenantAuth.listProviderConfigs({ type: 'saml' });
        const { providerConfigs: oidcProviderConfigs } = await tenantAuth.listProviderConfigs({ type: 'oidc' });

        resolve(samlProviderConfigs.concat(oidcProviderConfigs));
      } catch (error) {
        reject(error);
      }
    })
  }

  async getConfiguration(ipTenantId: string, providerId: string): Promise<AuthProviderConfig> {
    return new Promise(async (resolve, reject) => {
      try {
        const tenantAuth = this.getTenantAuth(ipTenantId);

        const providerConfig = await tenantAuth.getProviderConfig(providerId);

        resolve(providerConfig);
      } catch (error) {
        reject(error);
      }
    })
  }

  async createConfiguration(ipTenantId: string, configuration: IdentityPlatform.OidcProviderConfig | IdentityPlatform.SamlProviderConfig): Promise<void> {
    return new Promise(async (resolve, reject) => {
      try {
        const tenantAuth = this.getTenantAuth(ipTenantId);

        await tenantAuth.createProviderConfig(configuration);

        resolve();
      } catch (error) {
        reject(error);
      }
    })
  }

  async deleteConfiguration(ipTenantId: string, providerId: string): Promise<void> {
    return new Promise(async (resolve, reject) => {
      try {
        const tenantAuth = this.getTenantAuth(ipTenantId);

        await tenantAuth.deleteProviderConfig(providerId);

        resolve();
      } catch (error) {
        reject(error);
      }
    })
  }


  async getUserUUIDByEmail(email: string): Promise<string> {
    return new Promise(async (resolve, reject) => {
      try {
        const userRecord = await auth().getUserByEmail(email);
        const uuid = userRecord.uid;
        resolve(uuid);

      } catch (error) {

        reject(error);

      }
    })
  }

  async deleteUser(email: string): Promise<void> {
    return new Promise(async (resolve, reject) => {
      try {
        const uuid = await this.getUserUUIDByEmail(email);
        await auth().deleteUser(uuid);
        resolve();
      } catch (error) {
        reject(error);
      }
    })

  }


  // TODO : create type/interface for updated configuration body and add a parameter of the same to the function
  async updateConfiguration(ipTenantId: string, updateConfig: IdentityPlatform.SamlProviderConfig | IdentityPlatform.OidcProviderConfig): Promise<void> {
    return new Promise(async (resolve, reject) => {
      try {
        const tenantAuth = this.getTenantAuth(ipTenantId);

        const providerId = updateConfig.providerId;

        // const newConfig: any = updateConfig;
        // delete newConfig["providerId"];
        const newConfig: any = { ...updateConfig };
        delete newConfig.providerId;

        console.log("New Config",newConfig);

        await tenantAuth.updateProviderConfig(providerId, newConfig);

        resolve();
      } catch (error) {
        reject(error);
      }
    })
  }
}

export namespace IdentityPlatform {
  interface BaseProviderConfig {
    displayName: string;
    enabled: boolean;
    providerId: string;
  }

  export interface OidcProviderConfig extends BaseProviderConfig {
    clientId: string;
    issuer: string;
    responseType: {
      idToken: boolean
    };
  }

  export interface SamlProviderConfig extends BaseProviderConfig {
    idpEntityId: string;
    ssoURL: string;
    x509Certificates: Array<string>;
    rpEntityId: string;
    callbackURL: string;
  }
}