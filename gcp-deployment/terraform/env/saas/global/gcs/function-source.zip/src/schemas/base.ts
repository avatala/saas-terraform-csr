import * as yup from "yup";

export const requestPayload = yup.object({
  operation: yup.string().required()
});