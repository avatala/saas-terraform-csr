import { initializeApp, getApps } from "firebase-admin/app";

export class FirebaseService {
  constructor() {
    if (!getApps().length) {
      initializeApp();
    }
  }
}