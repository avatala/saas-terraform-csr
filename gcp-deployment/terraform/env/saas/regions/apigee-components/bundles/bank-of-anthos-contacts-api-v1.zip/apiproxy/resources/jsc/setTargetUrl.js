   var tenant = context.getVariable("request.header.tenant"); //cymbal-edtech
var customattributeUrl =  context.getVariable("app.contactUrl");//value is coming from app
var targeturl ;
urlcheckFlag = "false";
var kvmPortalurl= context.getVariable("kvmPortalurl");//value is set in KVM for Dev Portal
//10.56856
//###Apigee flow####
//checking value is coming from app

targeturl = tenant ? kvmPortalurl : customattributeUrl;
print(targeturl);
urlcheckFlag = "True";

//If url not set seting flag value to raise error
// context.setVariable('urlcheckFlag' , urlcheckFlag);
// var pathsuffix = context.getVariable("proxy.pathsuffix");
// context.setVariable("target.url" , targetUrl + pathsuffix);

var pathsuffix = context.getVariable("proxy.pathsuffix");
var url = targeturl + pathsuffix;
print("url=", url);
context.setVariable("responseurl", url);
// context.setVariable("target.url", url);
context.setVariable("target.url", targeturl + pathsuffix);